必须运行 AMD64 的镜像，可以使用 QEMU 来进行架构仿真。Docker Desktop 或 Docker Engine 支持 QEMU 仿真，可以让你在 ARM64 平台上运行 AMD64 的镜像
ARM64 平台上开启仿真   docker run --rm --privileged multiarch/qemu-user-static --reset -p yes

第一步：docker build -t tgsou .
第二步：docker run -it -p 9999:7860 --platform=linux/amd64 tgsou  输入登录信息后 访问 http://ip:9999/

